import React, { useState } from 'react';
import {View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image, ScrollView} from 'react-native';

const QUIZ = [
{
id: 1,
pergunta: 'Qual foi a data de lançamento da primeira HQ do Homem-Aranha?',
imagem: 'https://pt.wikipedia.org/wiki/Ficheiro:Usm100.PNG',
opcoes: ['5 de junho de 1962', '6 de maio de 1965', '10 de agosto de 1976','25 de setembro de 1984'],
respostaCerta: 0
},
{
id: 2,
pergunta: 'Qual foi o primeiro vilão a aparecer nas HQs do Homem-Aranha?',
imagem: '',
opcoes: ['Duende Verde', 'Abutre', 'Camaleão', 'Homem-Areia'],
respostaCerta: 2
},
{
id: 3,
pergunta: 'Qual foi a primeira tragédia na vida de Peter Parker?',
imagem: '',
opcoes: ['Morte do Capitão Stacy', 'Morte da Gwen', 'Morte do Tony Stark', 'Morte do Tio Ben'],
respostaCerta: 3
},
{
id: 4,
pergunta: 'Qual foi a primeira equipe de super-heróis que interagiu com o Homem-Aranha?',
imagem: '',
opcoes: ['X-Men', 'Vingadores', 'Quarteto Fantástico', 'Sociedade da Justiça' ],
respostaCerta: 2
},
{
id: 5,
pergunta: 'Qual vilão descobriu a identidade de Peter Parker nas HQs?',
imagem: '',
opcoes: ['Abutre', 'Homem-Hídrico', 'Rino', 'Duende Verde'
],
respostaCerta: 3
},
{
id: 6,
pergunta: 'Qual foi o primeiro crossover do Homem-Aranha com outro personagem?',
imagem: '',
opcoes: ['Superman', 'Homem de Ferro', 'Hulk', 'Galactus'
],
respostaCerta: 0
},
{
id: 7,
pergunta: 'Qual dessas NÃO é uma variante do Homem-Aranha?',
imagem: '',
opcoes: ['Miles Morales', 'Spider-Noir', 'Spider-CLT', 'Spider-Punk'],
respostaCerta: 2
},
{
id: 8,
pergunta: 'Quem foi o desenhista da Amazing Fantasy #15?',
imagem: '',
opcoes: ['Todd McFarlane','Steve Ditko', 'Jorge Jiménez', 'John Romita'],
respostaCerta: 1
},
{
id: 9,
pergunta: 'Em qual saga o vilão Chacal foi introduzido?',
imagem: '',
opcoes: ['Última Caçada de Kraven','Saga do Clone','Homem-Aranha Superior','Planejador Mestre'],
respostaCerta: 1
},
{
id: 10,
pergunta: 'Com qual entidade Peter fez um pacto para esququecerem que ele é o Homem-Aranha?',
imagem: '',
opcoes: ['Duende Verde', 'Mistério','Mephisto','JJJ'],
respostaCerta: 2
}
];

export default function App() {
const [telaAtual, setTelaAtual] = useState('inicio');
const [perguntaAtual, setPerguntaAtual] = useState(0);
const [pontuacao, setPontuacao] = useState(0);
const [carregando, setCarregando] = useState(false);

const [respostaSelecionada, setRespostaSelecionada] = useState(null);
const [travado, setTravado] = useState(false);

function iniciarJogo() {
setPerguntaAtual(0);
setPontuacao(0);
setRespostaSelecionada(null);
setTravado(false);
setTelaAtual('quiz');
}

function voltarAoInicio() {
setTelaAtual('inicio');
}

function responder(indiceClicado) {
if (travado) return;


setTravado(true);
setRespostaSelecionada(indiceClicado);

const pergunta = QUIZ[perguntaAtual];

setTimeout(() => {
  setCarregando(true);

  setTimeout(() => {
    if (indiceClicado === pergunta.respostaCerta) {
      setPontuacao((valorAtual) => valorAtual + 1);
    }

    if (perguntaAtual + 1 < QUIZ.length) {
      setPerguntaAtual((valorAtual) => valorAtual + 1);
      setRespostaSelecionada(null);
      setTravado(false);
    } else {
      setTelaAtual('resultado');
    }

    setCarregando(false);
  }, 1500);
}, 1000);


}

if (telaAtual === 'inicio') {
return ( <View style={styles.telaCentrada}> <Text style={styles.tituloPrincipal}> MIRANHA QUIZ</Text>



<Text style={styles.subtituloInicio}>
      Você é um verdadeiro fã do cabeça de teia?
</Text>

<TouchableOpacity
  style={styles.botaoIniciar}
  onPress={iniciarJogo}
>
<Text style={styles.textoBotaoIniciar}>
  INICIAR JOGO
</Text>
</TouchableOpacity>
  </View>
);

}

if (carregando) {
return ( <View style={styles.telaCentrada}> <ActivityIndicator size="large" color="#3b82f6" /> <Text style={styles.textoCarregando}>
Validando resposta... </Text> </View>
);
}

if (telaAtual === 'resultado') {
return ( <View style={styles.telaCentrada}> <Text style={styles.titulo}>Fim de Jogo!</Text>


<Text style={styles.subtitulo}>
  Você acertou {pontuacao} de {QUIZ.length} perguntas.
</Text>

<TouchableOpacity
  style={styles.botaoAcao}
  onPress={voltarAoInicio}
>
<Text style={styles.textoBotaoAcao}>
  Voltar ao Início
</Text>
</TouchableOpacity>
</View>
);


}

const pergunta = QUIZ[perguntaAtual];

return ( <ScrollView style={styles.tela}> <View style={styles.cabecalho}> <Text style={styles.progresso}>
Pergunta {perguntaAtual + 1} de {QUIZ.length} </Text>

<Text style={styles.pontos}>
  Pontos: {pontuacao}
</Text>
</View>

<View style={styles.cartaoPergunta}>
  <Image
  source={{ uri: pergunta.imagem }}
  style={styles.imagemPergunta}
/>

<Text style={styles.textoPergunta}>
  {pergunta.pergunta}
</Text>
  </View>

<View style={styles.areaOpcoes}>
    {pergunta.opcoes.map((opcao, index) => (
<TouchableOpacity
    key={index}
    disabled={travado}
    onPress={() => responder(index)}
    style={[
      styles.botaoOpcao,

    respostaSelecionada === index &&
    index === pergunta.respostaCerta &&
    styles.botaoCorreto,

    respostaSelecionada === index &&
    index !== pergunta.respostaCerta &&
    styles.botaoErrado
        ]}
>
  <Text style={styles.textoOpcao}>
    {opcao}
</Text>
</TouchableOpacity>
    ))}
  </View>
</ScrollView>


);
}

const styles = StyleSheet.create({
tela: {
flex: 1,
backgroundColor: '#f8fafc',
padding: 20,
paddingTop: 60
},

telaCentrada: {
flex: 1,
justifyContent: 'center',
alignItems: 'center',
backgroundColor: '#f8fafc',
padding: 20
},

tituloPrincipal: {
fontSize: 34,
fontWeight: '900',
marginBottom: 15
},

subtituloInicio: {
fontSize: 16,
textAlign: 'center',
marginBottom: 40
},

botaoIniciar: {
backgroundColor: '#10b981',
padding: 20,
borderRadius: 15
},

textoBotaoIniciar: {
color: '#fff',
fontWeight: 'bold'
},

cabecalho: {
flexDirection: 'row',
justifyContent: 'space-between',
marginBottom: 20
},

progresso: {
fontWeight: 'bold'
},

pontos: {
fontWeight: 'bold'
},

cartaoPergunta: {
backgroundColor: '#fff',
padding: 20,
borderRadius: 20,
marginBottom: 20
},

imagemPergunta: {
width: '100%',
height: 200,
borderRadius: 15,
marginBottom: 15
},

textoPergunta: {
fontSize: 20,
fontWeight: 'bold',
textAlign: 'center'
},

areaOpcoes: {
marginBottom: 30
},

botaoOpcao: {
backgroundColor: '#fff',
padding: 18,
borderRadius: 12,
marginBottom: 10,
borderWidth: 2,
borderColor: '#ddd'
},

textoOpcao: {
textAlign: 'center',
fontWeight: '600'
},

botaoCorreto: {
backgroundColor: '#22c55e',
borderColor: '#22c55e'
},

botaoErrado: {
backgroundColor: '#ef4444',
borderColor: '#ef4444'
},

titulo: {
fontSize: 32,
fontWeight: 'bold',
marginBottom: 10
},

subtitulo: {
fontSize: 18,
marginBottom: 30
},

botaoAcao: {
backgroundColor: '#3b82f6',
padding: 18,
borderRadius: 15
},

textoBotaoAcao: {
color: '#fff',
fontWeight: 'bold'
},

textoCarregando: {
marginTop: 20,
fontSize: 18
}
});
