import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function MeuPrimeiroApp() {

  const [curtidas, setCurtidas] = useState(0);
  const [curtido, setCurtido] = useState(false);

  function alternarCurtida() {

    if (curtido) {
      setCurtidas(curtidas - 1);
      setCurtido(false);
    } else {
      setCurtidas(curtidas + 1);
      setCurtido(true);
    }

  }

  return (
    <View style={styles.tela}>

      <Text style={styles.titulo}>Olá, Mundo Mobile!</Text>

      <Text style={styles.subtitulo}>
        Meu primeiro app rodando
      </Text>

      <TouchableOpacity
        style={styles.botao}
        onPress={alternarCurtida}
        activeOpacity={0.7}
      >
        <Text style={styles.textoBotao}>
          {curtido ? "❤️ Curtido" : "🤍 Curtir"}
        </Text>
      </TouchableOpacity>

      <Text style={styles.contador}>
        {curtidas} curtidas
      </Text>

    </View>
  );
}

const styles = StyleSheet.create({
  tela: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc'
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1e293b',
    textAlign: 'center'
  },

  subtitulo: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 30,
    textAlign: 'center'
  },

  botao: {
    backgroundColor: 'gray',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    width: 200,
    alignItems: 'center',
    justifyContent: 'center'
  },

  textoBotao: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    lineHeight: 24
  },

  contador: {
    marginTop: 20,
    fontSize: 20,
    fontWeight: 'bold'
  }
});