import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, SafeAreaView, Alert } from 'react-native';

const PETISCOS = [
  { id: '1', nome: 'Bifinho Magnus Carne', preco: 5.90, icone: '🥩' },
  { id: '2', nome: 'Sachê Pedigree Frango', preco: 3.50, icone: '🥫' },
  { id: '3', nome: 'Osso Mastigável', preco: 12.00, icone: '🦴' },
  { id: '4', nome: 'Suplemento Pelagem', preco: 45.00, icone: '✨' },
];

export default function PetShopApp() {
  // O carrinho agora vai guardar objetos com a propriedade "quantidade"
  const [carrinho, setCarrinho] = useState([]);

  // ==========================================
  // LÓGICA DE QUANTIDADE (O Cérebro do Carrinho)
  // ==========================================
  function adicionar(produto) {
    const itemExiste = carrinho.find((c) => c.id === produto.id);

    if (itemExiste) {
      // Se já existe, faz a fotocópia e soma +1 na quantidade
      setCarrinho(carrinho.map((c) => 
        c.id === produto.id ? { ...c, quantidade: c.quantidade + 1 } : c
      ));
    } else {
      // Se é o primeiro, entra com quantidade 1
      setCarrinho([...carrinho, { ...produto, quantidade: 1 }]);
    }
  }

  function remover(produtoId) {
    const item = carrinho.find((c) => c.id === produtoId);

    if (item.quantidade === 1) {
      // Se só tem 1 e o usuário clicou em remover, o item some do carrinho
      setCarrinho(carrinho.filter((c) => c.id !== produtoId));
    } else {
      // Se tem mais de 1, apenas subtrai da quantidade
      setCarrinho(carrinho.map((c) => 
        c.id === produtoId ? { ...c, quantidade: c.quantidade - 1 } : c
      ));
    }
  }

  function finalizarPedido() {
    // O Alert nativo do celular!
    Alert.alert(
      "Pedido Confirmado! 🎉",
      `O valor de R$ ${valorTotal.toFixed(2).replace('.', ',')} será cobrado na entrega.`,
      [
        { 
          text: "OK", 
          onPress: () => setCarrinho([]) // Esvazia o carrinho ao clicar em OK
        }
      ]
    );
  }

  // CÁLCULO AUTOMÁTICO (Preço * Quantidade)
  const valorTotal = carrinho.reduce((soma, item) => soma + (item.preco * item.quantidade), 0);
  const totalItens = carrinho.reduce((soma, item) => soma + item.quantidade, 0);

  // ==========================================
  // INTERFACE
  // ==========================================
  function desenharItem(item) {
    // Verifica se o item está no carrinho para descobrir a quantidade atual
    const itemNoCarrinho = carrinho.find((c) => c.id === item.id);
    const quantidade = itemNoCarrinho ? itemNoCarrinho.quantidade : 0;

    return (
      <View style={[styles.card, quantidade > 0 && styles.cardSelecionado]}>
        
        <View style={styles.infoProduto}>
          <Text style={styles.icone}>{item.icone}</Text>
          <View>
            <Text style={styles.nomeProduto}>{item.nome}</Text>
            <Text style={styles.precoProduto}>R$ {item.preco.toFixed(2).replace('.', ',')}</Text>
          </View>
        </View>

        {/* CONTROLES DE QUANTIDADE DINÂMICOS */}
        {quantidade === 0 ? (
          <TouchableOpacity style={styles.botaoAdicionar} onPress={() => adicionar(item)}>
            <Text style={styles.textoBotaoAdicionar}>+ Add</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.controlesQuantidade}>
            <TouchableOpacity style={styles.botaoMenosMais} onPress={() => remover(item.id)}>
              <Text style={styles.textoMenosMais}>-</Text>
            </TouchableOpacity>
            
            <Text style={styles.numeroQuantidade}>{quantidade}</Text>
            
            <TouchableOpacity style={styles.botaoMenosMais} onPress={() => adicionar(item)}>
              <Text style={styles.textoMenosMais}>+</Text>
            </TouchableOpacity>
          </View>
        )}

      </View>
    );
  }

  return (
    <SafeAreaView style={styles.tela}>
      <View style={styles.cabecalho}>
        <Text style={[styles.titulo, styles.titulo_Pet]}>Pet Shop em Casa 🐶</Text>
      </View>
      
      <FlatList 
        data={PETISCOS} 
        keyExtractor={(item) => item.id} 
        renderItem={({ item }) => desenharItem(item)} 
        contentContainerStyle={styles.areaLista}
      />

      {carrinho.length > 0 && (
        <View style={styles.barraInferior}>
          <View>
            <Text style={styles.textoResumo}>{totalItens} {totalItens === 1 ? 'item' : 'itens'}</Text>
            <Text style={styles.textoTotal}>Total: R$ {valorTotal.toFixed(2).replace('.', ',')}</Text>
          </View>
          
          <TouchableOpacity style={styles.botaoComprar} onPress={finalizarPedido}>
            <Text style={styles.textoBotaoComprar}>Avançar</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

// ==========================================
// ESTILOS
// ==========================================
const styles = StyleSheet.create({
  titulo_Pet: { color:'gray' },
  tela: { flex: 1, backgroundColor: '#f8fafc' },
  cabecalho: { padding: 20, paddingTop: 40, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#e2e8f0' },
  titulo: { fontSize: 24, fontWeight: '800', color: '#0f172a' },
  
  areaLista: { padding: 20, paddingBottom: 100 },
  
  card: { 
    backgroundColor: '#ffffff', 
    padding: 15, 
    borderRadius: 16, 
    marginBottom: 12,
    flexDirection: 'row', 
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: '#0f172a', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2
  },
  cardSelecionado: { borderColor: 'pink', backgroundColor: '#f8fafc' },
  
  infoProduto: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  icone: { fontSize: 30, marginRight: 12 },
  nomeProduto: { fontSize: 16, fontWeight: '700', color: '#334155' },
  precoProduto: { fontSize: 16, color: '#10b981', fontWeight: '800', marginTop: 4 },
  
  /* Botão de Adicionar Inicial */
  botaoAdicionar: { backgroundColor: '#eff6ff', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 8, borderWidth: 1, borderColor: '#bfdbfe' },
  textoBotaoAdicionar: { color: '#3b82f6', fontWeight: 'bold', fontSize: 14 },
  
  /* Controles de + e - */
  controlesQuantidade: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f1f5f9', borderRadius: 8, padding: 4 },
  botaoMenosMais: { backgroundColor: 'white', width: 32, height: 32, borderRadius: 6, justifyContent: 'center', alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 2, elevation: 1 },
  textoMenosMais: { fontSize: 18, fontWeight: 'bold', color: '#3b82f6' },
  numeroQuantidade: { fontSize: 16, fontWeight: 'bold', color: '#0f172a', width: 30, textAlign: 'center' },
  
  /* Barra Flutuante */
  barraInferior: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: '#3b82f6', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, paddingBottom: 30, borderTopLeftRadius: 20, borderTopRightRadius: 20, shadowColor: '#000', shadowOpacity: 0.2, shadowOffset: { width: 0, height: -5 }, elevation: 15 },
  textoResumo: { color: '#bfdbfe', fontSize: 14, fontWeight: '600' },
  textoTotal: { color: 'white', fontSize: 20, fontWeight: '800' },
  botaoComprar: { backgroundColor: 'white', paddingVertical: 12, paddingHorizontal: 24, borderRadius: 10 },
  textoBotaoComprar: { color: '#3b82f6', fontWeight: '800', fontSize: 16 }
});