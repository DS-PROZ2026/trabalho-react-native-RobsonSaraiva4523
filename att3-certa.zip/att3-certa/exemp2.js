import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'

export default function ModoEscuroApp(){
  const [escuro, setEscuro] = useState(false);

  return(
   <View style={[styles.tela, escuro ? styles.fundoEscuro : styles.fundoClaro]}>
   <Text style={[styles.texto, escuro ? styles.textoEscuro : styles.textoClaro]}>
   {escuro ? 'Boa noite! 🌛' : 'Bom dia! 🌞'}
   </Text>
   <TouchableOpacity
    style={styles.botao}
    onPress={() => setEscuro(!escuro)}
   >
    <Text style={styles.textoBotao}>Trocar Tema</Text>
  </TouchableOpacity>
  </View>
  );
}
const styles = StyleSheet.create({
  tela: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  
  // Cores de Fundo
  fundoClaro: { backgroundColor: '#ffffff' },
  fundoEscuro: { backgroundColor: '#1e293b' },
  
  // Cores do Texto
  textoClaro: { color: '#000000' },
  textoEscuro: { color: '#ffffff' },
  
  texto: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  botao: { backgroundColor: '#3b82f6', padding: 15, borderRadius: 8 },
  textoBotao: { color: 'white', fontWeight: 'bold', fontSize: 16 }
});